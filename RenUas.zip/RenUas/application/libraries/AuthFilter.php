<?php
defined('BASEPATH') or exit('No direct script access allowed');

class AuthFilter
{

    protected $CI;

    public function __construct()
    {
        $this->CI = &get_instance();
        $this->CI->load->library('session');
        $this->CI->load->helper('url');
    }

    public function check_login()
    {
        if (!$this->CI->session->userdata('user_logged')) {
            redirect('auth'); // Ganti 'auth/login' dengan URL login Anda
        }
    }
}
