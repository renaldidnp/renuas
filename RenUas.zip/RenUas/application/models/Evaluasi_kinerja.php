<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Evaluasi_kinerja extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function get_all_evaluasikinerja()
    {
        $query = $this->db->get('evaluasikinerja');
        return $query->result();
    }

    public function get_evaluasikinerja_by_id($id)
    {
        $query = $this->db->get_where('evaluasikinerja', array('id' => $id));
        return $query->row();
    }

    public function tambah_evaluasikinerja($data)
    {
        return $this->db->insert('evaluasikinerja', $data);
    }

    public function edit_evaluasikinerja($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('evaluasikinerja', $data);
    }

    public function hapus_evaluasikinerja($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('evaluasikinerja');
    }

    public function cari_evaluasikinerja($keyword)
    {
        $this->db->like('nama_karyawan', $keyword);
        $query = $this->db->get('evaluasikinerja');

        return $query->result();
    }
}
