<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_karyawan extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();  // Load database

    }

    public function get_all_karyawan()
    {
        $query = $this->db->get('karyawan');
        return $query->result();
    }

    public function getJumlahKaryawan()
    {
        $query = $this->db->query("SELECT COUNT(*) AS total_karyawan FROM karyawan");
        $row = $query->row();
        return $row->total_karyawan;
    }

    public function get_karyawan_by_id($id)
    {
        $query = $this->db->get_where('karyawan', array('id' => $id));
        return $query->row();
    }

    public function tambah_karyawan($data)
    {
        return $this->db->insert('karyawan', $data);
    }

    public function edit_karyawan($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('karyawan', $data);
    }

    public function hapus_karyawan($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('karyawan');
    }

    public function cari_karyawan($keyword)
    {
        $this->db->like('nama', $keyword);
        $this->db->or_like('jabatan', $keyword);
        $query = $this->db->get('karyawan');

        return $query->result();
    }
}
