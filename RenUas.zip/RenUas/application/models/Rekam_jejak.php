<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Rekam_jejak extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function get_all_rekamjejak()
    {
        $query = $this->db->get('rekamjejak');
        return $query->result();
    }

    public function get_rekamjejak_by_id($id)
    {
        $query = $this->db->get_where('rekamjejak', array('id' => $id));
        return $query->row();
    }

    public function tambah_rekamjejak($data)
    {
        return $this->db->insert('rekamjejak', $data);
    }

    public function edit_rekamjejak($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('rekamjejak', $data);
    }

    public function hapus_rekamjejak($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('rekamjejak');
    }

    public function cari_rekamjejak($keyword)
    {
        $this->db->like('nama', $keyword);
        $query = $this->db->get('rekamjejak');

        return $query->result();
    }
}
