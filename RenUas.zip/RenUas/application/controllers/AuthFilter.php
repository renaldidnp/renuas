<?php
defined('BASEPATH') or exit('No direct script access allowed');

class AuthFilter
{

    protected $CI;

    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->library('authfilter'); // Memuat library AuthFilter
    }


    public function check_login()
    {
        if (!$this->CI->session->userdata('logged_in')) {
            redirect('auth'); // Ganti 'auth/login' dengan URL login Anda
        }
    }
}
