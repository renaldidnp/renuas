<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Datakaryawan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Data_karyawan');
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library('authfilter'); // Memuat library AuthFilter

        // Pengecekan otentikasi pada konstruktor

    }

    public function index()
    {
        $this->authfilter->check_login();
        $data['karyawan'] = $this->Data_karyawan->get_all_karyawan();
        $this->load->view('templates/header');
        $this->load->view('dashboard/datakaryawan', $data);
        $this->load->view('templates/footer');
    }

    public function tambah()
    {
        // Load form validation library
        $this->load->library('form_validation');

        // Set rules for form validation
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('tanggal_lahir', 'Tanggal Lahir', 'required|date');
        $this->form_validation->set_rules('gaji', 'Gaji', 'required|numeric');
        $this->form_validation->set_rules('jabatan', 'Jabatan', 'required');

        if ($this->form_validation->run() === FALSE) {
            // Jika validasi gagal, kembali ke halaman tambah karyawan
            $this->load->view('templates/header');
            $this->load->view('Dashboard/addkaryawan');
        } else {
            // Jika validasi sukses, tambahkan karyawan ke database
            $data = array(
                'nama' => $this->input->post('nama'),
                'alamat' => $this->input->post('alamat'),
                'tanggal_lahir' => $this->input->post('tanggal_lahir'),
                'gaji' => $this->input->post('gaji'),
                'jabatan' => $this->input->post('jabatan')
            );

            $this->Data_karyawan->tambah_karyawan($data);

            // Redirect ke halaman indeks karyawan atau halaman lain yang sesuai
            redirect('datakaryawan');
        }
    }

    public function edit($id)
    {
        $data['karyawan'] = $this->Data_karyawan->get_karyawan_by_id($id);
        $this->load->view('templates/header');
        $this->load->view('dashboard/editkaryawan', $data);
    }

    public function update($id)
    {
        // Mengambil data yang di-submit dari form
        $data = array(
            'nama' => $this->input->post('nama'),
            'alamat' => $this->input->post('alamat'),
            'tanggal_lahir' => $this->input->post('tanggal_lahir'),
            'gaji' => $this->input->post('gaji'),
            'jabatan' => $this->input->post('jabatan')
        );

        // Memanggil method model untuk melakukan update data karyawan
        $this->Data_karyawan->edit_karyawan($id, $data);

        // Redirect kembali ke halaman index atau halaman lain setelah update berhasil
        redirect('datakaryawan/index');
    }



    public function hapus($id)
    {
        // Pastikan ID yang diterima valid
        if (!empty($id)) {
            // Panggil method dari model untuk menghapus karyawan berdasarkan ID
            $this->Data_karyawan->hapus_karyawan($id);

            // Set flashdata untuk memberikan pesan bahwa karyawan telah dihapus
            $this->session->set_flashdata('success', 'Data karyawan berhasil dihapus.');

            // Redirect kembali ke halaman index atau halaman lain setelah berhasil menghapus
            redirect('datakaryawan/index');
        } else {
            // Jika ID kosong atau tidak valid, tampilkan pesan error atau redirect ke halaman error
            // Misalnya:
            // show_error('ID karyawan tidak valid', 404);
            redirect('datakaryawan/index'); // Redirect jika tidak valid
        }
    }

    public function search()
    {
        // Ambil keyword dari input form
        $keyword = $this->input->get('keyword');

        // Panggil method dari model untuk melakukan pencarian karyawan
        $data['karyawan'] = $this->Data_karyawan->cari_karyawan($keyword);

        // Load view dengan hasil pencarian
        $this->load->view('templates/header');
        $this->load->view('dashboard/datakaryawan', $data);
    }
}
