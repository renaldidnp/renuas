<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->model('Data_karyawan');
        $this->load->library('authfilter'); // Memuat library AuthFilter
    }


    public function index()
    {
        $this->authfilter->check_login();
        $data['totalKaryawan'] = $this->Data_karyawan->getJumlahKaryawan();

        // Load view dengan data yang sudah disiapkan
        $this->load->view('templates/header');
        $this->load->view('dashboard/admin', $data); // Kirim $data ke view admin
        $this->load->view('templates/footer');
    }
}
