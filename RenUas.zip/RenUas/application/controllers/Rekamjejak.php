<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Rekamjejak extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Rekam_jejak');
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library('authfilter'); // Memuat library AuthFilter

        // Pengecekan otentikasi pada konstruktor

    }

    public function index()
    {
        $this->authfilter->check_login();

        $data['rekamjejak'] = $this->Rekam_jejak->get_all_rekamjejak();
        $this->load->view('templates/header');
        $this->load->view('rekamjejak/index', $data);
        $this->load->view('templates/footer');
    }

    public function tambah()
    {
        // Load form validation library
        $this->load->library('form_validation');

        // Set rules for form validation
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required|date');
        $this->form_validation->set_rules('kegiatan', 'Kegiatan', 'required');
        $this->form_validation->set_rules('keterangan', 'Keterangan', 'required');

        if ($this->form_validation->run() === FALSE) {
            // Jika validasi gagal, kembali ke halaman tambah rekamjejak
            $this->load->view('templates/header');
            $this->load->view('rekamjejak/addrekam');
        } else {
            // Jika validasi sukses, tambahkan rekamjejak ke database
            $data = array(
                'nama' => $this->input->post('nama'),
                'tanggal' => $this->input->post('tanggal'),
                'kegiatan' => $this->input->post('kegiatan'),
                'keterangan' => $this->input->post('keterangan'),
            );

            $this->Rekam_jejak->tambah_rekamjejak($data);

            // Redirect ke halaman indeks rekamjejak atau halaman lain yang sesuai
            redirect('rekamjejak');
        }
    }

    public function edit($id)
    {
        $data['rekamjejak'] = $this->Rekam_jejak->get_rekamjejak_by_id($id);
        $this->load->view('templates/header');
        $this->load->view('rekamjejak/editrekam', $data);
    }

    public function update($id)
    {
        // Mengambil data yang di-submit dari form
        $data = array(
            'nama' => $this->input->post('nama'),
            'tanggal' => $this->input->post('tanggal'),
            'kegiatan' => $this->input->post('kegiatan'),
            'keterangan' => $this->input->post('keterangan'),
        );

        // Memanggil method model untuk melakukan update data karyawan
        $this->Rekam_jejak->edit_rekamjejak($id, $data);

        // Redirect kembali ke halaman index atau halaman lain setelah update berhasil
        redirect('rekamjejak/index');
    }



    public function hapus($id)
    {
        // Pastikan ID yang diterima valid
        if (!empty($id)) {
            // Panggil method dari model untuk menghapus karyawan berdasarkan ID
            $this->Rekam_jejak->hapus_rekamjejak($id);

            // Set flashdata untuk memberikan pesan bahwa karyawan telah dihapus
            $this->session->set_flashdata('success', 'Data karyawan berhasil dihapus.');

            // Redirect kembali ke halaman index atau halaman lain setelah berhasil menghapus
            redirect('rekamjejak/index');
        } else {
            // Jika ID kosong atau tidak valid, tampilkan pesan error atau redirect ke halaman error
            // Misalnya:
            // show_error('ID karyawan tidak valid', 404);
            redirect('rekamjejak/index'); // Redirect jika tidak valid
        }
    }

    public function search()
    {
        // Ambil keyword dari input form
        $keyword = $this->input->get('keyword');

        // Panggil method dari model untuk melakukan pencarian karyawan
        $data['rekamjejak'] = $this->Rekam_jejak->cari_rekamjejak($keyword);

        // Load view dengan hasil pencarian
        $this->load->view('templates/header');
        $this->load->view('rekamjejak/index', $data);
    }
}
