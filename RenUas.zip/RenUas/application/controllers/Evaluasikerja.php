<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Evaluasikerja extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Evaluasi_kinerja');
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library('authfilter'); // Memuat library AuthFilter

    }

    public function index()
    {
        $this->authfilter->check_login();

        $data['evaluasikinerja'] = $this->Evaluasi_kinerja->get_all_evaluasikinerja();
        $this->load->view('templates/header');
        $this->load->view('evaluasikerja/index', $data);
        $this->load->view('templates/footer');
    }

    public function tambah()
    {
        // Load form validation library
        $this->load->library('form_validation');

        // Set rules for form validation
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('tanggal_evaluasi', 'Tanggal_evaluasi', 'required|date');
        $this->form_validation->set_rules('kegiatan', 'Kegiatan', 'required');
        $this->form_validation->set_rules('keterangan', 'Keterangan', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('templates/header');
            $this->load->view('evaluasikerja/addevaluasi');
        } else {
            $data = array(
                'nama_karyawan' => $this->input->post('nama_karyawan'),
                'tanggal_evaluasi' => $this->input->post('tanggal_evaluasi'),
                'kegiatan' => $this->input->post('kegiatan'),
                'keterangan' => $this->input->post('keterangan'),
            );

            $this->Evaluasi_kinerja->tambah_evaluasikinerja($data);

            // Redirect ke halaman indeks rekamjejak atau halaman lain yang sesuai
            redirect('evaluasikerja');
        }
    }

    public function edit($id)
    {
        $data['evaluasikinerja'] = $this->Evaluasi_kinerja->get_evaluasikinerja_by_id($id);
        $this->load->view('templates/header');
        $this->load->view('evaluasikerja/editevaluasi', $data);
    }

    public function update($id)
    {
        $data = array(
            'nama_karyawan' => $this->input->post('nama_karyawan'),
            'tanggal_evaluasi' => $this->input->post('tanggal_evaluasi'),
            'hasil_evaluasi' => $this->input->post('hasil_evaluasi'),
            'keterangan' => $this->input->post('keterangan')
        );

        $this->Evaluasi_kinerja->edit_evaluasikinerja($id, $data);

        redirect('evaluasikerja/index');
    }



    public function hapus($id)
    {
        // Pastikan ID yang diterima valid
        if (!empty($id)) {
            // Panggil method dari model untuk menghapus karyawan berdasarkan ID
            $this->Evaluasi_kinerja->hapus_evaluasikinerja($id);

            // Set flashdata untuk memberikan pesan bahwa karyawan telah dihapus
            $this->session->set_flashdata('success', 'Data karyawan berhasil dihapus.');

            // Redirect kembali ke halaman index atau halaman lain setelah berhasil menghapus
            redirect('evaluasikerja/index');
        } else {
            // Jika ID kosong atau tidak valid, tampilkan pesan error atau redirect ke halaman error
            // Misalnya:
            // show_error('ID karyawan tidak valid', 404);
            redirect('evaluasikerja/index'); // Redirect jika tidak valid
        }
    }

    public function search()
    {
        // Ambil keyword dari input form
        $keyword = $this->input->get('keyword');

        // Panggil method dari model untuk melakukan pencarian karyawan
        $data['karyawan'] = $this->Data_karyawan->cari_karyawan($keyword);

        // Load view dengan hasil pencarian
        $this->load->view('templates/header');
        $this->load->view('dashboard/datakaryawan', $data);
    }
}
