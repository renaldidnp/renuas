<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span> Rekam Jejak</h4>

    <div class="mb-4 row">
        <div class="col-md-6">
            <a href="<?= site_url('rekamjejak/tambah') ?>" class="btn btn-primary btn-block">Tambah Rekam Jejak</a>
        </div>
        <div class="col-md-6 mt-2 mt-md-0">
            <form action="<?= site_url('rekamjejak/search') ?>" method="GET" class="form-inline">
                <div class="input-group">
                    <input type="text" name="keyword" class="form-control" placeholder="Cari rekam jejak...">
                    <div class="input-group-append">
                        <button type="submit" class="btn btn-outline-secondary">Search</button>
                        <button type="button" class="btn btn-outline-secondary" onclick="resetForm()">Reset</button>
                    </div>
                </div>
            </form>
        </div>
    </div>



    <!-- Basic Bootstrap Table -->
    <div class="card">
        <h5 class="card-header">Manajemen Rekam Jejak</h5>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Lengkap</th>
                        <th>Tanggal Dibuat</th>
                        <th>Kegiatan</th>
                        <th>Keterangan</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rekamjejak as $k) { ?>
                        <tr>
                            <td><?= $k->id ?></td>
                            <td><?= $k->nama ?></td>
                            <td><?= $k->tanggal ?></td>
                            <td><?= $k->kegiatan ?></td>
                            <td><?= $k->keterangan ?></td>
                            <td class="action-buttons">
                                <a class="btn btn-primary" href="<?= site_url('rekamjejak/edit/' . $k->id) ?>">Edit</a>
                                <a class="btn btn-danger" href="<?= site_url('rekamjejak/hapus/' . $k->id) ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus karyawan ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!--/ Basic Bootstrap Table -->

</div>

<script>
    function resetForm() {
        // Mengosongkan inputan form
        document.querySelector('input[name="keyword"]').value = '';

        // Melakukan submit ulang form
        document.querySelector('form').submit();
    }
</script>


<style>
    .action-buttons {
        display: flex;
        gap: 5px;
        /* Jarak antara tombol-tombol */
    }
</style>