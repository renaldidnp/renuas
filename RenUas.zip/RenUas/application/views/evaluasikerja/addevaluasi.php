<!-- / Navbar -->

<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Evaluasi Kinerja /</span> Tambah Evalusia Kinerja</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">
                        <h5 class="mb-0"></h5>
                    </div>
                    <div class="card-body">
                        <?php echo validation_errors(); ?>
                        <?php echo form_open('evaluasikerja/tambah'); ?>
                        <div class="mb-3 row">
                            <label for="nama" class="col-sm-2 col-form-label">Nama Karyawan:</label>
                            <div class="col-sm-10">
                                <input type="text" name="nama_karyawan" id="nama_karyawan" class="form-control" value="<?= set_value('nama') ?>">
                            </div>
                        </div>

                        <div class="mb-3 row">
                            <label for="alamat" class="col-sm-2 col-form-label">Tanggal Evaluasi:</label>
                            <div class="col-sm-10">
                                <input type="date" name="tanggal_evaluasi" id="tanggal_evaluasi" class="form-control" value="<?= set_value('tanggal') ?>">
                            </div>
                        </div>



                        <div class="mb-3 row">
                            <label for="kegiatan" class="col-sm-2 col-form-label">Hasil Evaluasi</label>
                            <div class="col-sm-10">
                                <input type="text" name="hasil_evaluasi" id="hasil_evaluasi" class="form-control" value="<?= set_value('kegiatan') ?>">
                            </div>
                        </div>


                        <div class="mb-3 row">
                            <label for="keterangan" class="col-sm-2 col-form-label">Keterangan:</label>
                            <div class="col-sm-10">
                                <input type="text" name="keterangan" id="keterangan" class="form-control" value="<?= set_value('keterangan') ?>">
                            </div>
                        </div>

                        <div class="row justify-content-end">
                            <div class="col-sm-10">
                                <a href="<?= site_url('evaluasikerja') ?>" class="btn btn-danger btn-block">Batal</a>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                        </div>

                        <?php echo form_close(); ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<!-- / Content -->