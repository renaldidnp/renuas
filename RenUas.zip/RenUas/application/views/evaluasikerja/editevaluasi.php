<!-- / Navbar -->

<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Data Evaluasi Kinerja /</span> Edit Evaluasi Kinerja</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col-xxl">
                <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">
                        <h5 class="mb-0"></h5>
                    </div>
                    <div class="card-body">
                        <form action="<?= site_url('evaluasikerja/update/' . $evaluasikinerja->id) ?>" method="post">
                            <div class="mb-3 row">
                                <label for="nama" class="col-sm-2 col-form-label">Nama Karyawan:</label>
                                <div class="col-sm-10">
                                    <input type="text" name="nama_karyawan" id="nama_karyawan" class="form-control" value="<?= $evaluasikinerja->nama_karyawan ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="tanggal" class="col-sm-2 col-form-label">Tanggal Evaluasi:</label>
                                <div class="col-sm-10">
                                    <input type="date" name="tanggal_evaluasi" id="tanggal_evaluasi" class="form-control" value="<?= $evaluasikinerja->tanggal_evaluasi ?>">
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label for="gaji" class="col-sm-2 col-form-label">Hasil Evaluasi:</label>
                                <div class="col-sm-10">
                                    <input type="text" name="hasil_evaluasi" id="hasil_evaluasi" class="form-control" value="<?= $evaluasikinerja->hasil_evaluasi ?>">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="jabatan" class="col-sm-2 col-form-label">Keterangan:</label>
                                <div class="col-sm-10">
                                    <input type="text" name="keterangan" id="keterangan" class="form-control" value="<?= $evaluasikinerja->keterangan ?>">
                                </div>
                            </div>
                            <div class="row justify-content-end">
                                <div class="col-sm-10">
                                    <a href="<?= site_url('evaluasikerja') ?>" class="btn btn-danger btn-block">Batal</a>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- / Content -->