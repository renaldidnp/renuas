<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="py-3 mb-4"><span class="text-muted fw-light">Dashboard /</span> Data Karyawan</h4>

    <div class="mb-4 row">
        <div class="col-md-6">
            <a href="<?= site_url('datakaryawan/tambah') ?>" class="btn btn-primary btn-block">Tambah Karyawan</a>
        </div>
        <div class="col-md-6 mt-2 mt-md-0">
            <form action="<?= site_url('datakaryawan/search') ?>" method="GET" class="form-inline">
                <div class="input-group">
                    <input type="text" name="keyword" class="form-control" placeholder="Cari karyawan...">
                    <div class="input-group-append">
                        <button type="submit" class="btn btn-outline-secondary">Search</button>
                        <button type="button" class="btn btn-outline-secondary" onclick="resetForm()">Reset</button>
                    </div>
                </div>
            </form>
        </div>
    </div>



    <!-- Basic Bootstrap Table -->
    <div class="card">
        <h5 class="card-header">Manajamen Data Karyawan</h5>
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Lengkap</th>
                        <th>Alamat</th>
                        <th>Tanggal Lahir</th>
                        <th>Gaji</th>
                        <th>Jabatan</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php foreach ($karyawan as $k) { ?>
                        <tr>
                            <td><?= $k->id ?></td>
                            <td><?= $k->nama ?></td>
                            <td><?= $k->alamat ?></td>
                            <td><?= $k->tanggal_lahir ?></td>
                            <td><?= $k->gaji ?></td>
                            <td><?= $k->jabatan ?></td>
                            <td>
                                <a class="btn btn-primary" href="<?= site_url('datakaryawan/edit/' . $k->id) ?>">Edit</a>
                                <a class="btn btn-danger" href="<?= site_url('datakaryawan/hapus/' . $k->id) ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus karyawan ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <!--/ Basic Bootstrap Table -->

</div>

<script>
    function resetForm() {
        // Mengosongkan inputan form
        document.querySelector('input[name="keyword"]').value = '';

        // Melakukan submit ulang form
        document.querySelector('form').submit();
    }
</script>